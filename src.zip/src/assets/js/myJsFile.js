/*function myfunction()
{
	var path = "C:\\path\\Test.txt"
var fs = require('fs')
fs.readFile(path , 'utf8', function(err, data) {
  if (err) throw err;
  console.log('OK: ' + filename);
  console.log(data)
});
}*/

function getData(){       //this will read file and send information to other function
	var xmlhttp;

	if (window.XMLHttpRequest) {
		xmlhttp = new XMLHttpRequest();               
	}           
	else {               
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");               
	}

	xmlhttp.onreadystatechange = function () {               
		if (xmlhttp.readyState == 4) {                   
		  var lines = xmlhttp.responseText;    //*here we get all lines from text file*

		  intoArray(lines);     //here we call function with parameter "lines*"                   
		}               
	}

	xmlhttp.open("GET", "file:///C:\\path\\Test.txt", true);
	xmlhttp.send();    
}

function intoArray (lines) {
// splitting all text data into array "\n" is splitting data from each new line
//and saving each new line as each element*

var lineArr = lines.split('\n'); 

//just to check if it works output lineArr[index] as below
document.write(lineArr[2]);         
document.write(lineArr[3]);
}

function myMethod(){
	alert("Loaded");
}

function openFile() {
	alert("before");
  document.getElementById('inp').click();
  
  //alert(document.getElementById('inp').click());
}
function readFile(e) {
	alert(e.target.files[0]);
  var file = e.target.files[0];
  if (!file) return;
  var reader = new FileReader();
  reader.onload = function(e) {	
    document.getElementById('contents').innerHTML = e.target.result;
  }
  reader.readAsText(file)
}